# Thesis_code
#run autorun.sh 5 times
#Download the documents generated in /home folder of the VM
#run genererate final results codes get final results
