tar -xvf Testcodes.tar.gz
cd Thesis_Codes/
./Bench_test.sh
shutdown 5
exit
