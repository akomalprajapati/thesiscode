#QuickMB tool
#Quick_MB_Results/ contains the results generated using QuickMB tool
#The data is generated using QuickMB tool running over various Virtual Machines of Google Cloud Platform
#For more description of Hardware of the VM visit results/Data.docx
#Research_work_data/ contains details of research work and complete details required for the project
#Research_work_data/ data can be used as an evidence of Impact of the Tool and can be used to understand the nature of Project and utility.
